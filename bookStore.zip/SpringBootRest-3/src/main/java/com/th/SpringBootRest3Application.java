package com.th;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRest3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRest3Application.class, args);
	}

}
